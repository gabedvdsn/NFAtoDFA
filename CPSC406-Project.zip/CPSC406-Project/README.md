### Identifying Information

Gabriel Davidson
2338642
gadavidson@chapman.edu

CPSC-406-01 > Project : NFA to DFA Converter

### Source Files

- main.py

### Compile or runtime errors, code limitations, & deviations from assignment specifications

- Does not include a space between individual states in converted state names in output file
- If the character between the symbols in the input file is not '\t' it will not work
    - Some text editors automatically replace tabs with spaces
    - The output file will reflect this if the input file is not formatted correctly

### References

- None

### Instructions

1. Download project files
2. Run main.py file from command line using

   **python3 main.py {input file}**  [Default output file is "output.txt"]

   or

   **python3 main.py {input file} {output file}**

#### Notes
- I added evaluation of the provided sample input with some example strings