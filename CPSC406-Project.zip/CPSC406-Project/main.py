import sys
import time

EPS = "EPS"
EMPTY = "∅"


class Transition:
    def __init__(self, on, to):
        self.on = on
        self.to = to


class FiniteAutomata:
    def __init__(self, Q: list[str], Sigma: list[str], q0: str, d: dict[str: list[Transition]], F: list[str]):
        self.data = {'Q': Q, 'S': Sigma, 'q0': q0, 'd': d, 'F': F}

        # If a string is to evaluate False, recurse depth is very large
        # To combat this, a collective memory is used to remember the evaluation of substrings
        # This can be used for as many evaluations of any string for this FA
        self.memory = {}

        # More discussion on memory:
        # Memory benefits only NFAs, and a DFA model would benefit more from iteration rather than recursion
        # Still, this cuts down runtime when evaluating invalid strings on DFA models dramatically
        # If the string is to evaluate True, then this runs in O(n) time regardless of model type

    def __getitem__(self, item):
        if isinstance(item, tuple):
            raise Exception("Cannot use multi-dimensional indexing")

        if item in self.data:
            return self.data[item]

        raise KeyError(f"Invalid key '{item}'")

    def __setitem__(self, key, value):
        if isinstance(key, tuple):
            raise Exception("Cannot use multi-dimensional indexing")

        if key in self.data:
            self.data[key] = value
            return

        raise KeyError(f"Invalid key '{key}'")

    def Evaluate(self, string: str) -> bool:
        print(f"\nBEGIN EVALUATION OF {string}")
        start_time = time.time()

        result = self._Evaluate(string, self.data['q0'])  # Initial recurse call

        end_time = time.time()
        print(f"END EVALUATION OF {string} | Result: {result}")
        print(f"Evaluation time: {end_time - start_time}\n")

        return result  # Return result

    def _Evaluate(self, string: str, start: str) -> bool:
        # This method recursively finds the evaluation of a string
        curr = self.data['q0'] if start is None else start

        print(f"Curr: {curr}   String: {string}")

        for i, symbol in enumerate(string):
            transitions = self.GetTransitionsOn(curr, symbol)

            if not transitions:
                return False  # Assumed transition to ∅ if no valid transitions

            for transition in transitions:
                curr = transition.to

                # If this string X state exist in memory, fetch result
                # If evaluation is UNKNOWN, the substring exists but memory does not know how to evaluate from curr
                if self.FindEvaluationInMemory(string[i + 1:], curr):
                    return self.memory[string[i + 1:]][curr]

                # Recurse for next state and remaining string.
                # If transition is on EPS, recurse for curr state and remaining substring
                status = self._Evaluate(string[i + 1:], transition.to) if transition.on is not EPS else self._Evaluate(
                    string[i + 1:], transition.to) & self._Evaluate(string[i + 1:], curr)

                if status:
                    self.memory[string[i + 1:]][curr] = True  # Record result
                    return status

                self.memory[string[i + 1:]][curr] = False  # Record result

        self.memory[string][start] = curr in self.data['F']  # Record result
        return curr in self.data['F']

    def FindEvaluationInMemory(self, string: str, curr: str) -> bool:
        # Returns whether this exists in memory, not how the string evaluates from curr
        if string in self.memory:
            print(
                "[MEMORY] " + '{' + f"{curr}" + '}' + f" evaluated with '{string}' is " +
                f"{self.memory[string][curr] if curr in self.memory[string] else 'UNKNOWN'}")
            return curr in self.memory[string]
        else:
            self.memory[string] = {}  # If it doesn't exist, add it

        return False

    def GetTransitionsOn(self, state, symbol) -> list[Transition]:
        # Fetches all transitions from state on symbol
        transitions = []
        if state in self.data['Q']:
            for transition in self.data['d'][state]:
                if transition.on == symbol:
                    transitions.append(transition)
                if transition.on == EPS:  # Account for EPS transition
                    transitions.append(transition)
        return transitions


class NFAtoDFA:
    @staticmethod
    def ConvertNFAFromFile(filename: str) -> FiniteAutomata:
        return NFAtoDFA.Convert(NFAtoDFA.ParseNFAFromFile(filename))

    @staticmethod
    def ParseNFAFromFile(filename) -> FiniteAutomata:
        nfa = FiniteAutomata(Q=[], Sigma=[], q0="", d={}, F=[])

        with open(filename, 'r') as f:
            for i, line in enumerate(f):
                if i == 0:  # Q
                    for state in line.split('}'):
                        nfa['Q'].append(state.strip()[1:])
                elif i == 1:  # Sigma
                    for symbol in line.split('\t'):
                        nfa['S'].append(symbol.split('\n')[0])
                elif i == 2:  # q0
                    nfa['q0'] = line[1:line.rindex('}')]
                elif i == 3:  # F
                    for state in line.split('}'):
                        nfa['F'].append(state.strip()[1:])
                elif i == 4:  # d
                    if line != "BEGIN\n":
                        raise Exception("Input file is not formatted correctly")
                    for _state in nfa['Q']:
                        nfa['d'][_state] = []
                else:
                    if line == "END" or line == "END\n":
                        break

                    # parse origin state
                    transition = line.split(',')
                    state = transition[0][1:transition[0].rindex('}')]

                    # parse symbol & nextState
                    transition = transition[1].split('=')
                    symbol = transition[0].strip()
                    nextState = transition[1].strip()[1:transition[1].rindex('}') - 1]
                    nfa['d'][state].append(Transition(symbol, nextState))  # Add to d

        # Cleaning
        nfa['Q'] = [q for q in nfa['Q'] if q]
        nfa['S'] = [s for s in nfa['S'] if s]
        nfa['F'] = [fQ for fQ in nfa['F'] if fQ]

        return nfa

    @staticmethod
    def WriteFAToFile(fa, filename="output.txt") -> bool:

        # Sorting and formatting to clean up output1.txt

        # Q can be sorted by length, or left in order of discovery
        # fa['Q'] = sorted(fa['Q'], key=lambda x: len(x.split(',')))  # Sorting by length of state

        fa['Q'].remove(fa['q0'])
        fa['Q'].insert(0, fa['q0'])  # Make sure q0 is at front of Q

        if "EM" in fa['Q']:  # Make sure EM is at end of Q, if it exists
            fa['Q'].remove("EM")
            fa['Q'].append("EM")

        for _state in fa['Q']:  # Make sure transition functions for each state are ordered by symbol
            fa['d'][_state] = sorted(fa['d'][_state], key=lambda x: x.on)

        fa['F'] = sorted(fa['F'], key=lambda x: len(x.split(',')))  # Sorting by length of state

        try:
            with open(filename, 'w') as f:
                # Write states
                f.write("\t".join(['{' + q + '}' for q in fa['Q']]) + '\n')  # Add brackets

                # Write Sigma
                f.write("\t".join(fa['S']) + '\n')

                # Write q0
                f.write('{' + fa['q0'] + '}' + '\n')  # Add brackets

                # Write accept states
                f.write("\t".join(['{' + fQ + '}' for fQ in fa['F']]) + '\n')  # Add brackets

                # Write transitions
                f.write("BEGIN" + '\n')

                for _state in fa['Q']:
                    for transition in fa['d'][_state]:
                        f.write('{' + _state + '},' + f" {transition.on} = " + "{" + transition.to + "}" + '\n')

                f.write("END" + '\n')

        except Exception as e:
            print(e)
            return False

        return True

    @staticmethod
    def Convert(nfa: FiniteAutomata):
        # DFA as dict. Can already calculate new start state
        # noinspection PyDictCreation
        dfa = FiniteAutomata(Q=[], Sigma=nfa['S'], q0=NFAtoDFA.FullEpsilonClosure(nfa, nfa['q0']), d={}, F=[])

        # Get converted states and transitions at the same time
        dfa['Q'], dfa['d'] = NFAtoDFA.ConvertStatesAndTransitions(nfa, dfa['q0'])
        # Get converted accept states
        dfa['F'] = NFAtoDFA.ConvertAcceptStates(dfa, nfa['F'])

        return dfa

    @staticmethod
    def ConvertStatesAndTransitions(nfa: FiniteAutomata, q0: str) -> (list[str], dict[str: list[Transition]]):
        Q = [q0]
        d = {q0: []}

        stateQueue = [q0]
        limit, counter = len(nfa['Q']) * (len(nfa['S']) + 1), 1
        # While there are still states we have not calculated closure on
        while stateQueue and counter < limit:
            nextState = stateQueue.pop()  # Also ensures we only include valid states in Q
            if nextState == "EM":  # We know these transitions already
                d["EM"] = [Transition(_symbol, "EM") for _symbol in nfa['S']]
                continue
            # Consume all symbols at each state to find transitions
            for _symbol in nfa['S']:
                qPrime = NFAtoDFA.ConvertState(nfa, nextState, _symbol)

                if not qPrime:
                    qPrime = "EM"

                if qPrime not in Q:  # We have not seen this state before
                    Q.append(qPrime)
                    stateQueue.insert(0, qPrime)  # Add to queue

                    d[qPrime] = []

                d[nextState].append(Transition(_symbol, qPrime))  # Transition: nextState on _symbol goes to qPrime

            counter += 1

        return Q, d

    @staticmethod
    def ConvertAcceptStates(dfa: FiniteAutomata, F: list[str]) -> list[str]:
        FPrime = []
        for fQ in F:
            for q in dfa['Q']:
                if fQ in q.split(',') and q not in FPrime:  # Check if dfa state contains any nfa accept state
                    FPrime.append(q)

        return FPrime

    @staticmethod
    def ConvertState(nfa: FiniteAutomata, _state: str, _symbol: str) -> str:
        _q = ""
        for _state in _state.split(','):
            # Get all states travelled to from _state on _symbol
            stateClosure = NFAtoDFA.TotalStateClosureOn(nfa, _state, _symbol)
            _q += ("," if _q and stateClosure else "") + stateClosure

            # Take epsilon closures of each state travelled to
            for _Qs in stateClosure.split(','):
                epsClosure = NFAtoDFA.EpsilonClosure(nfa, _Qs) if stateClosure else ""
                _q += ("," if _q and epsClosure else "") + epsClosure

        return NFAtoDFA.CombineClosures(_q)

    @staticmethod
    def TotalStateClosureOn(nfa: FiniteAutomata, _state: str, _symbol: str) -> str:
        _q = ""
        if _state in nfa['Q']:
            for transition in nfa['d'][_state]:  # Iterate over each transition contained at _state
                if transition.on == _symbol:  # This transition goes on _symbol
                    _q += ("," if _q else "") + transition.to

        return NFAtoDFA.CombineClosures(_q)

    @staticmethod
    def FullEpsilonClosure(nfa: FiniteAutomata, _state: str) -> str:
        # This function recursively finds the full epsilon closure of _state
        _q = _state
        if _state in nfa['Q']:
            for transition in nfa['d'][_state]:
                if transition.on == EPS:  # Epsilon transition found
                    # Concatenate full epsilon closure of state travelled to
                    _q += "," + NFAtoDFA.FullEpsilonClosure(nfa, transition.to)

        return NFAtoDFA.CombineClosures(_q)

    @staticmethod
    def EpsilonClosure(nfa: FiniteAutomata, _state: str) -> str:
        # Clarity function. E(q) is the total state closure of _state on "EPS"
        return NFAtoDFA.TotalStateClosureOn(nfa, _state, EPS)

    @staticmethod
    def CombineClosures(qPrime: str) -> str:
        # Removes duplicates and sorts qPrime
        return ','.join(sorted(set(qPrime.split(','))))


def main():
    # Can include second command line param for output1.txt file
    args = sys.argv[1:]

    if not args:  # No params included
        raise Exception("Please include filename as param")

    inFile = args[0]

    # Convert to DFA
    nfa = NFAtoDFA.ParseNFAFromFile(inFile)
    dfa = NFAtoDFA.Convert(nfa)

    # Some evaluations on the sample nfa and converted dfa
    string1 = "aabbabaaba"  # True
    string2 = "aabab"  # False

    nfa.Evaluate(string1)
    nfa.Evaluate(string2)

    dfa.Evaluate(string1)
    dfa.Evaluate(string2)

    # You can see how useful the memory becomes with the second evaluation for each model.
    # Almost all recursion calls are stopped before going to depth.
    # Also, the empty string appears in Sigma for some reason. This leads to ∅ and also truncates recursion.

    # Write to output1.txt
    if not args[1:]:
        return NFAtoDFA.WriteFAToFile(dfa)
    else:  # Output filename param included
        return NFAtoDFA.WriteFAToFile(dfa, args[1])


if __name__ == "__main__":
    main()
